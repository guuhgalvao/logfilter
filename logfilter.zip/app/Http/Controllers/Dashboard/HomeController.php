<?php

namespace App\Http\Controllers\Dashboard;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class HomeController extends Controller
{
    public function index() {
        $logs = file(storage_path('app/public/logs/syslog.log'));

        $logsFiltered = [];
        foreach ($logs as $row) {
            $log = trim(strval($row));
            $logSplited = explode(',', substr($log, strpos($log, 'date=')));

            $logFiltered = [];
            foreach ($logSplited as $logInfo) {
                $infoSplited = explode('=', $logInfo);
                $logFiltered[trim($infoSplited[0])] = $infoSplited[1];
            }

            $logsFiltered[] = $logFiltered;
        }
        // dd($logsFiltered);
        return view('filter', ['logs' => $logsFiltered]);
    }
}
