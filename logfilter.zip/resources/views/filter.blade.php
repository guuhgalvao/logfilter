<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Favicon -->
        <link rel="shortcut icon" href="{{{ asset('img/favicon.png') }}}">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="{{ asset('css/app.css') }}" rel="stylesheet">
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            ::-webkit-scrollbar-track {
                -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
                background-color: #F5F5F5;
            }

            ::-webkit-scrollbar {
                width: 10px;
                background-color: #F5F5F5;
            }

            ::-webkit-scrollbar-thumb {
                background-color: #535353;
                /* border: 2px solid #555555; */
            }
        </style>
    </head>
    <body>
        <div id="app">
            <div class="container-fluid">
                <main class="py-4">
                    <div class="col-12 mb-1 pb-1">
                        <div class="row justify-content-center">
                            <h3>Logs</h3>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-borderless table-light">
                            <thead class="thead-dark">
                                <tr class="">
                                    <th class="">Date</th>
                                    <th>Time</th>
                                    <th>Type</th>
                                    <th>SubType</th>
                                    <th>User</th>
                                    <th>Group</th>
                                    <th>srcIP</th>
                                    <th>srcINTF</th>
                                    <th>dstIP</th>
                                    <th>dstINTF</th>
                                    <th>HostName</th>
                                    <th>Profile</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($logs as $log)
                                    <tr>
                                        <td>{{ $log['date'] ?? '-' }}</td>
                                        <td>{{ str_replace(' ', '', $log['time']) ?? '-' }}</td>
                                        <td>{{ $log['type'] ?? '-' }}</td>
                                        <td>{{ $log['subtype'] ?? '-' }}</td>
                                        <td>{{ $log['user'] ?? '-' }}</td>
                                        <td>{{ $log['group'] ?? '-' }}</td>
                                        <td>{{ $log['srcip'] ?? '-' }}</td>
                                        <td>{{ $log['srcintf'] ?? '-' }}</td>
                                        <td>{{ $log['dstip'] ?? '-' }}</td>
                                        <td>{{ $log['dstintf'] ?? '-' }}</td>
                                        <td>{{ $log['hostname'] ?? '-' }}</td>
                                        <td>{{ $log['profile'] ?? '-' }}</td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    {{-- <div class="card border-primary">
                        <div class="card-header bg-primary text-white">
                            Logs
                        </div>

                    </div> --}}
                </main>
            </div>
        </div>
        <script src="{{ asset('js/app.js') }}"></script>
    </body>
</html>
