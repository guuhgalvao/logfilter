<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- Favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('img/favicon.png')); ?>">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <title><?php echo e(config('app.name', 'Laravel')); ?></title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">

        <!-- Styles -->
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            ::-webkit-scrollbar-track {
                -webkit-box-shadow: inset 0 0 6px rgba(0,0,0,0.3);
                background-color: #F5F5F5;
            }

            ::-webkit-scrollbar {
                width: 10px;
                background-color: #F5F5F5;
            }

            ::-webkit-scrollbar-thumb {
                background-color: #535353;
                /* border: 2px solid #555555; */
            }
        </style>
    </head>
    <body>
        <div id="app">
            <div class="container-fluid">
                <main class="py-4">
                    <div class="col-12 mb-1 pb-1">
                        <div class="row justify-content-center">
                            <h3>Logs</h3>
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="table table-striped table-borderless table-light">
                            <thead class="thead-dark">
                                <tr class="">
                                    <th class="">Date</th>
                                    <th>Time</th>
                                    <th>Type</th>
                                    <th>SubType</th>
                                    <th>User</th>
                                    <th>Group</th>
                                    <th>srcIP</th>
                                    <th>srcINTF</th>
                                    <th>dstIP</th>
                                    <th>dstINTF</th>
                                    <th>HostName</th>
                                    <th>Profile</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($log['date'] ?? '-'); ?></td>
                                        <td><?php echo e(str_replace(' ', '', $log['time']) ?? '-'); ?></td>
                                        <td><?php echo e($log['type'] ?? '-'); ?></td>
                                        <td><?php echo e($log['subtype'] ?? '-'); ?></td>
                                        <td><?php echo e($log['user'] ?? '-'); ?></td>
                                        <td><?php echo e($log['group'] ?? '-'); ?></td>
                                        <td><?php echo e($log['srcip'] ?? '-'); ?></td>
                                        <td><?php echo e($log['srcintf'] ?? '-'); ?></td>
                                        <td><?php echo e($log['dstip'] ?? '-'); ?></td>
                                        <td><?php echo e($log['dstintf'] ?? '-'); ?></td>
                                        <td><?php echo e($log['hostname'] ?? '-'); ?></td>
                                        <td><?php echo e($log['profile'] ?? '-'); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                </main>
            </div>
        </div>
        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
    </body>
</html>
<?php /**PATH C:\Users\Gustavo Galvão\Documents\Development\logfilter\resources\views/filter.blade.php ENDPATH**/ ?>